import { beforeEach, describe, expect, it } from 'vitest'
import { useInspectionStore } from './store'

beforeEach(() => {
  useInspectionStore.setState({
    hovered: null,
    pinned: [],
    draft: [],
    relationships: [],
    tool: 'select',
    showAutomatic: true,
    categories: { size: true, form: true, radii: false, orientation: false },
  })
})

describe('inspection interaction state', () => {
  it('pins and unpins the same semantic feature', () => {
    useInspectionStore.getState().togglePinned('feature_0001')
    expect(useInspectionStore.getState().pinned).toEqual(['feature_0001'])
    useInspectionStore.getState().togglePinned('feature_0001')
    expect(useInspectionStore.getState().pinned).toEqual([])
  })

  it('clears pinned, hover, and relationship draft selections together', () => {
    useInspectionStore.setState({ hovered: 'feature_0001', pinned: ['feature_0001'], draft: ['feature_0002'] })
    useInspectionStore.getState().clearSelections()
    expect(useInspectionStore.getState()).toMatchObject({ hovered: null, pinned: [], draft: [] })
  })

  it('keeps a relationship draft pair unique and bounded', () => {
    const state = useInspectionStore.getState()
    state.addDraft('a'); state.addDraft('a'); state.addDraft('b'); state.addDraft('c')
    expect(useInspectionStore.getState().draft).toEqual(['a', 'b'])
  })
})

export type Point = [number, number]

export interface FeatureRecord {
  id: string
  type: string
  semantic?: string
  confidence?: number
  status: string
  support?: Point[][]
  closed?: boolean[]
  geometry?: Record<string, unknown>
  parent?: string
}

export interface MeasurementRecord {
  id: string
  operator: string
  feature_refs: string[]
  status: string
  value: number | number[] | null
  units?: string
  method?: string
  minimum?: number
  maximum?: number
  average?: number
  witness?: Point[]
  minimum_witness?: Point[]
  maximum_witness?: Point[]
  reason?: string
}

export interface Analysis {
  path: string
  name: string
  imageUrl: string
  width: number
  height: number
  prediction: { features: Array<Record<string, unknown>>; threshold: number }
  report: {
    features: FeatureRecord[]
    measurements: MeasurementRecord[]
    summary: { measured: number; failed_or_unavailable: number; tolerance_failures: number }
    extraction?: Record<string, unknown>
  }
  timingsMs: { edges: number; recognition: number; measurement: number }
}

export type Tool = 'select' | 'distance_statistics' | 'angle'
export type MeasurementCategory = 'size' | 'form' | 'radii' | 'orientation'

declare global {
  interface Window {
    inspection: {
      chooseImage(): Promise<string | null>
      analyze(path: string): Promise<Analysis>
      measureRelationship(request: Record<string, unknown>): Promise<MeasurementRecord>
      defaultSample(): Promise<string>
    }
  }
}

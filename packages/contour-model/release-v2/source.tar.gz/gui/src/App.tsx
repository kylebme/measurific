import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import * as Tooltip from '@radix-ui/react-tooltip'
import {
  ChevronDown, CircleDotDashed, Crosshair, FolderOpen, TriangleRight,
  LoaderCircle, MousePointer2, Ruler, Trash2, X,
} from 'lucide-react'
import { useInspectionStore } from './store'
import type { FeatureRecord, MeasurementCategory, MeasurementRecord, Point, Tool } from './types'

const colors: Record<string, string> = {
  line: '#39d6b4', arc: '#f37c9b', circle: '#ab8dff', arbitrary_profile: '#70e080',
  full_round_slot: '#ff8d63', triangular_thread: '#f3d34a', trapezoidal_thread: '#45c6ef',
  flat: '#39d6b4', chamfer: '#f7bb50', fillet: '#f37c9b', shoulder: '#6eb5ff',
  hole: '#ab8dff', slot: '#ff8d63', groove: '#f56868', taper: '#45c6ef',
  thread: '#f3d34a', tooth_profile: '#e786ff', rounded_profile: '#70e080',
  external_profile: '#8a97a8', polygon: '#81d4a8', notch: '#ff836f', tab: '#56b8ff',
}

const categoryOperators: Record<MeasurementCategory, string[]> = {
  size: ['length', 'least_squares_diameter', 'width', 'overall_length', 'arc_length', 'area', 'perimeter'],
  form: ['straightness', 'circularity_ls', 'rms_residual', 'peak_to_valley_residual', 'max_abs_residual'],
  radii: ['radius', 'corner_radius', 'end_radius'],
  orientation: ['orientation', 'angular_span'],
}

function formatValue(value: unknown, units = '') {
  if (typeof value === 'number') return `${value.toFixed(value >= 100 ? 1 : 3)}${units ? ` ${units}` : ''}`
  if (Array.isArray(value)) return `[${value.map((v) => typeof v === 'number' ? v.toFixed(2) : v).join(', ')}] ${units}`
  return '—'
}

function featureName(feature: FeatureRecord) {
  return (feature.semantic || feature.type || 'feature').replaceAll('_', ' ')
}

function featureCenter(feature: FeatureRecord): Point {
  const center = feature.geometry?.center
  if (Array.isArray(center) && center.length === 2) return center as Point
  const points = feature.support?.flat() || []
  if (!points.length) return [0, 0]
  return [points.reduce((sum, p) => sum + p[0], 0) / points.length,
    points.reduce((sum, p) => sum + p[1], 0) / points.length]
}

function featurePath(feature: FeatureRecord) {
  return (feature.support || []).map((run, index) => {
    if (!run.length) return ''
    const closed = feature.closed?.[index]
    return `M ${run.map((p) => `${p[0].toFixed(2)} ${p[1].toFixed(2)}`).join(' L ')}${closed ? ' Z' : ''}`
  }).join(' ')
}

function measurementCategory(operator: string): MeasurementCategory | null {
  for (const [category, operators] of Object.entries(categoryOperators)) {
    if (operators.includes(operator)) return category as MeasurementCategory
  }
  return null
}

function FeatureTooltip({ feature, measurements }: { feature: FeatureRecord; measurements: MeasurementRecord[] }) {
  const useful = measurements.filter((m) => m.status === 'measured').slice(0, 5)
  return <div className="feature-tooltip">
    <div className="tooltip-title"><span>{featureName(feature)}</span><span className="mono">{feature.id.replace('feature_', '#')}</span></div>
    <div className="tooltip-meta">{feature.type} · {feature.confidence == null ? 'user' : `${Math.round(feature.confidence * 100)}% confidence`}</div>
    {useful.length ? <div className="tooltip-values">{useful.map((m) =>
      <div key={m.id}><span>{m.operator.replaceAll('_', ' ')}</span><strong>{formatValue(m.value, m.units)}</strong></div>,
    )}</div> : <div className="tooltip-empty">No automatic measurement available</div>}
  </div>
}

function ImageStage({ onFeatureClick }: { onFeatureClick: (feature: FeatureRecord) => void }) {
  const { analysis, hovered, pinned, draft, relationships, showAutomatic, categories, setHovered } = useInspectionStore()
  const stageRef = useRef<HTMLDivElement>(null)
  const [pointer, setPointer] = useState({ x: 0, y: 0 })
  if (!analysis) return <div className="empty-stage"><Crosshair size={42}/><h2>No image loaded</h2><p>Open an image to run edge detection and semantic recognition.</p></div>

  const features = analysis.report.features.filter((feature) => feature.status === 'fitted' && feature.support?.length)
  const automaticFor = (id: string) => analysis.report.measurements.filter((m) => m.feature_refs.length === 1 && m.feature_refs[0] === id)
  const visibleAutomatic = analysis.report.measurements.filter((m) => {
    const category = measurementCategory(m.operator)
    return showAutomatic && m.status === 'measured' && m.feature_refs.length === 1 && category && categories[category]
  })

  const positionFor = (feature: FeatureRecord) => {
    const bounds = stageRef.current?.getBoundingClientRect()
    if (!bounds) return { left: 0, top: 0 }
    const ratio = analysis.width / analysis.height
    let width = bounds.width, height = width / ratio, ox = 0, oy = (bounds.height - height) / 2
    if (height > bounds.height) { height = bounds.height; width = height * ratio; oy = 0; ox = (bounds.width - width) / 2 }
    const [x, y] = featureCenter(feature)
    const left = ox + x / analysis.width * width
    const top = oy + y / analysis.height * height
    return {
      left: Math.max(126, Math.min(bounds.width - 126, left)),
      top: Math.max(20, Math.min(bounds.height - 20, top)),
    }
  }
  const hoveredFeature = features.find((f) => f.id === hovered)

  return <div className="image-stage" ref={stageRef} onPointerMove={(event) => {
    const bounds = stageRef.current?.getBoundingClientRect()
    if (bounds) setPointer({ x: event.clientX - bounds.left + 14, y: event.clientY - bounds.top + 14 })
  }}>
    <img src={analysis.imageUrl} alt={analysis.name} draggable={false}/>
    <svg className="feature-overlay" viewBox={`0 0 ${analysis.width} ${analysis.height}`} preserveAspectRatio="xMidYMid meet">
      {relationships.flatMap((measurement) => {
        const witness = measurement.minimum_witness || measurement.witness
        if (!witness || witness.length !== 2) return []
        return <g key={measurement.id} className="witness">
          <line x1={witness[0][0]} y1={witness[0][1]} x2={witness[1][0]} y2={witness[1][1]}/>
          <circle cx={witness[0][0]} cy={witness[0][1]} r="4"/><circle cx={witness[1][0]} cy={witness[1][1]} r="4"/>
        </g>
      })}
      {features.sort((a, b) => (a.semantic === 'external_profile' ? -1 : b.semantic === 'external_profile' ? 1 : 0)).map((feature) => {
        const active = hovered === feature.id || pinned.includes(feature.id) || draft.includes(feature.id)
        const color = colors[feature.semantic || ''] || '#57c7ff'
        return <g key={feature.id} className={active ? 'feature active' : 'feature'}>
          <path className="hit-path" d={featurePath(feature)} onPointerEnter={() => setHovered(feature.id)} onPointerLeave={() => setHovered(null)} onClick={() => onFeatureClick(feature)}/>
          <path className="visible-path" d={featurePath(feature)} style={{ stroke: color }}/>
        </g>
      })}
    </svg>
    {features.map((feature) => {
      const measurements = visibleAutomatic.filter((m) => m.feature_refs[0] === feature.id)
      const measurement = measurements[0]
      if (!feature) return null
      if (!measurement) return null
      const position = positionFor(feature)
      return <div key={feature.id} className="measure-label" style={position}>
        {measurement.operator.replaceAll('_', ' ')} <b>{formatValue(measurement.value, measurement.units)}</b>
        {measurements.length > 1 && <i>+{measurements.length - 1}</i>}
      </div>
    })}
    {hoveredFeature && !pinned.includes(hoveredFeature.id) && <div className="floating-tooltip" style={{ left: pointer.x, top: pointer.y }}>
      <FeatureTooltip feature={hoveredFeature} measurements={automaticFor(hoveredFeature.id)}/>
    </div>}
    {pinned.map((id) => {
      const feature = features.find((f) => f.id === id)
      if (!feature) return null
      return <div key={id} className="floating-tooltip pinned-tooltip" style={positionFor(feature)}>
        <FeatureTooltip feature={feature} measurements={automaticFor(id)}/>
      </div>
    })}
  </div>
}

function ToolButton({ tool, active, icon, label, onClick }: { tool: Tool; active: boolean; icon: React.ReactNode; label: string; onClick: () => void }) {
  return <Tooltip.Root><Tooltip.Trigger asChild>
    <button className={`tool-button ${active ? 'active' : ''}`} onClick={onClick} aria-label={label} data-tool={tool}>{icon}</button>
  </Tooltip.Trigger><Tooltip.Portal><Tooltip.Content className="radix-tooltip" side="right">{label}<Tooltip.Arrow className="tooltip-arrow"/></Tooltip.Content></Tooltip.Portal></Tooltip.Root>
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return <button className="toggle-row" onClick={onChange}><span>{label}</span><span className={`switch ${checked ? 'on' : ''}`}><i/></span></button>
}

function InspectorPanel({ runRelationship }: { runRelationship: (anchors: string[], statistic: string) => Promise<void> }) {
  const { analysis, tool, draft, relationships, showAutomatic, categories, toggleAutomatic, toggleCategory, removeRelationship, error } = useInspectionStore()
  const [anchors, setAnchors] = useState(['edge', 'edge'])
  const [statistic, setStatistic] = useState('minimum')
  const [open, setOpen] = useState(true)
  const selectedFeatures = draft.map((id) => analysis?.report.features.find((f) => f.id === id)).filter(Boolean) as FeatureRecord[]
  const featureAllowsCenter = (feature?: FeatureRecord) => feature && ['circle', 'arc', 'ellipse', 'elliptical_arc', 'slot', 'rounded_rectangle'].includes(feature.type)

  return <aside className="inspector-panel">
    <section className="panel-section">
      <button className="section-title" onClick={() => setOpen(!open)}><span>Automatic measurements</span><ChevronDown size={15} className={open ? 'rotated' : ''}/></button>
      {open && <div className="section-body">
        <Toggle checked={showAutomatic} onChange={toggleAutomatic} label="Show on image"/>
        <div className={!showAutomatic ? 'subtoggles disabled' : 'subtoggles'}>
          {(Object.keys(categories) as MeasurementCategory[]).map((category) =>
            <label key={category}><input type="checkbox" checked={categories[category]} onChange={() => toggleCategory(category)}/><span>{category}</span></label>,
          )}
        </div>
      </div>}
    </section>

    <section className="panel-section relationship-builder">
      <div className="eyebrow">Measurement primitive</div>
      <h3>{tool === 'distance_statistics' ? 'Pairwise distance' : tool === 'angle' ? 'Included angle' : 'Select a tool'}</h3>
      {tool === 'select' ? <p className="hint">Choose distance or angle from the left toolbar, then select two outlined features.</p> : <>
        <div className="selection-slots">
          {[0, 1].map((index) => <div className={selectedFeatures[index] ? 'selection-slot filled' : 'selection-slot'} key={index}>
            <span>{index + 1}</span><div>{selectedFeatures[index] ? <><b>{featureName(selectedFeatures[index])}</b><small>{selectedFeatures[index].id}</small></> : <em>Click a feature</em>}</div>
          </div>)}
        </div>
        {tool === 'distance_statistics' && <div className="relationship-options">
          {[0, 1].map((index) => <label key={index}>Feature {index + 1} point
            <select value={anchors[index]} onChange={(event) => setAnchors((old) => old.map((v, i) => i === index ? event.target.value : v))}>
              <option value="edge">Feature edge</option>
              {featureAllowsCenter(selectedFeatures[index]) && <option value="center">Fitted center</option>}
            </select>
          </label>)}
          <label>Primary result<select value={statistic} onChange={(event) => setStatistic(event.target.value)}>
            <option value="minimum">Nearest</option><option value="maximum">Farthest</option><option value="average">Average</option>
          </select></label>
        </div>}
        <button className="primary-button" disabled={draft.length !== 2} onClick={() => runRelationship(anchors, statistic)}>Add measurement</button>
      </>}
      {error && <div className="inline-error">{error}</div>}
    </section>

    <section className="panel-section results-section">
      <div className="eyebrow">Pinned results</div>
      {!relationships.length ? <p className="hint">Relative measurements will appear here and on the image.</p> : relationships.map((result) =>
        <article className="result-card" key={result.id}>
          <button className="icon-button" onClick={() => removeRelationship(result.id)}><X size={14}/></button>
          <div className="result-kind">{result.operator === 'angle' ? 'Angle' : 'Distance'}</div>
          <strong>{formatValue(result.value, result.units)}</strong>
          {result.operator === 'distance_statistics' && <dl><div><dt>Minimum</dt><dd>{formatValue(result.minimum, 'px')}</dd></div><div><dt>Maximum</dt><dd>{formatValue(result.maximum, 'px')}</dd></div><div><dt>Average</dt><dd>{formatValue(result.average, 'px')}</dd></div></dl>}
          <small>{result.feature_refs.map((id) => id.replace('feature_', '#')).join(' ↔ ')}</small>
        </article>,
      )}
    </section>
  </aside>
}

export default function App() {
  const store = useInspectionStore()
  const { analysis, loading, tool, setAnalysis, setLoading, setError, setTool, togglePinned, addDraft, clearSelections, clearDraft, addRelationship } = store

  const loadImage = useCallback(async (path: string) => {
    setLoading(true); setError(null)
    try { setAnalysis(await window.inspection.analyze(path)) }
    catch (error) { setError(error instanceof Error ? error.message : String(error)) }
    finally { setLoading(false) }
  }, [setAnalysis, setError, setLoading])

  useEffect(() => { window.inspection.defaultSample().then(loadImage) }, [loadImage])
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') clearSelections() }
    window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey)
  }, [clearSelections])

  const openImage = async () => { const path = await window.inspection.chooseImage(); if (path) await loadImage(path) }
  const onFeatureClick = (feature: FeatureRecord) => {
    if (tool === 'select') togglePinned(feature.id)
    else if (tool === 'angle' && feature.type !== 'line') setError('Angle measurements require two fitted line features.')
    else { setError(null); addDraft(feature.id) }
  }
  const runRelationship = async (anchors: string[], statistic: string) => {
    const draft = useInspectionStore.getState().draft
    if (draft.length !== 2) return
    setError(null)
    try {
      const result = await window.inspection.measureRelationship({ id: `user_${Date.now()}`, operator: tool, featureA: draft[0], featureB: draft[1], anchors, statistic })
      addRelationship(result); clearDraft()
    } catch (error) { setError(error instanceof Error ? error.message : String(error)) }
  }
  const totalMs = useMemo(() => analysis ? Object.values(analysis.timingsMs).reduce((sum, value) => sum + value, 0) : 0, [analysis])

  return <main className="app-shell">
    <header className="top-bar">
      <div className="brand"><span className="brand-mark"><CircleDotDashed size={19}/></span><span>Telecentric Inspector</span><i>Prototype</i></div>
      <div className="image-status">{analysis && <><span className="status-dot"/>{analysis.name}<small>{analysis.width} × {analysis.height} · {analysis.report.summary.measured} measurements · {(totalMs / 1000).toFixed(1)}s</small></>}</div>
      <button className="open-button" onClick={openImage}><FolderOpen size={16}/>Open image</button>
    </header>
    <div className="workspace">
      <nav className="tool-rail">
        <ToolButton tool="select" active={tool === 'select'} icon={<MousePointer2 size={20}/>} label="Inspect and pin features" onClick={() => setTool('select')}/>
        <div className="tool-separator"/>
        <ToolButton tool="distance_statistics" active={tool === 'distance_statistics'} icon={<Ruler size={20}/>} label="Pairwise distance" onClick={() => setTool('distance_statistics')}/>
        <ToolButton tool="angle" active={tool === 'angle'} icon={<TriangleRight size={20}/>} label="Angle between lines" onClick={() => setTool('angle')}/>
        <div className="rail-spacer"/>
        <Tooltip.Root><Tooltip.Trigger asChild><button className="tool-button" onClick={clearSelections}><Trash2 size={19}/></button></Tooltip.Trigger><Tooltip.Portal><Tooltip.Content className="radix-tooltip" side="right">Clear selections (Esc)</Tooltip.Content></Tooltip.Portal></Tooltip.Root>
      </nav>
      <ImageStage onFeatureClick={onFeatureClick}/>
      <InspectorPanel runRelationship={runRelationship}/>
    </div>
    {loading && <div className="loading-screen"><LoaderCircle className="spinner" size={30}/><strong>Analyzing image</strong><span>Subpixel edges · semantic model · measurements</span></div>}
  </main>
}

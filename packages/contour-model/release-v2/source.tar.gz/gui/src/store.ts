import { create } from 'zustand'
import type { Analysis, MeasurementCategory, MeasurementRecord, Tool } from './types'

interface AppState {
  analysis: Analysis | null
  loading: boolean
  error: string | null
  tool: Tool
  hovered: string | null
  pinned: string[]
  draft: string[]
  relationships: MeasurementRecord[]
  showAutomatic: boolean
  categories: Record<MeasurementCategory, boolean>
  setAnalysis: (analysis: Analysis | null) => void
  setLoading: (loading: boolean) => void
  setError: (error: string | null) => void
  setTool: (tool: Tool) => void
  setHovered: (id: string | null) => void
  togglePinned: (id: string) => void
  addDraft: (id: string) => void
  clearSelections: () => void
  clearDraft: () => void
  addRelationship: (result: MeasurementRecord) => void
  removeRelationship: (id: string) => void
  toggleAutomatic: () => void
  toggleCategory: (category: MeasurementCategory) => void
}

export const useInspectionStore = create<AppState>((set) => ({
  analysis: null,
  loading: false,
  error: null,
  tool: 'select',
  hovered: null,
  pinned: [],
  draft: [],
  relationships: [],
  showAutomatic: true,
  categories: { size: true, form: true, radii: false, orientation: false },
  setAnalysis: (analysis) => set({ analysis, relationships: [], pinned: [], draft: [], hovered: null }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  setTool: (tool) => set({ tool, draft: [] }),
  setHovered: (hovered) => set({ hovered }),
  togglePinned: (id) => set((state) => ({
    pinned: state.pinned.includes(id) ? state.pinned.filter((value) => value !== id) : [...state.pinned, id],
  })),
  addDraft: (id) => set((state) => ({
    draft: state.draft.includes(id) || state.draft.length >= 2 ? state.draft : [...state.draft, id],
  })),
  clearSelections: () => set({ pinned: [], draft: [], hovered: null }),
  clearDraft: () => set({ draft: [] }),
  addRelationship: (result) => set((state) => ({ relationships: [result, ...state.relationships] })),
  removeRelationship: (id) => set((state) => ({ relationships: state.relationships.filter((item) => item.id !== id) })),
  toggleAutomatic: () => set((state) => ({ showAutomatic: !state.showAutomatic })),
  toggleCategory: (category) => set((state) => ({ categories: { ...state.categories, [category]: !state.categories[category] } })),
}))

const { app, BrowserWindow, dialog, ipcMain } = require('electron')
const { spawn } = require('node:child_process')
const { readFile } = require('node:fs/promises')
const path = require('node:path')

const root = path.resolve(__dirname, '..', '..')
const guiRoot = path.resolve(__dirname, '..')
let worker
let nextId = 1
const pending = new Map()

function pythonPath() {
  return process.env.INSPECTION_PYTHON || path.join(guiRoot, '.venv', 'bin', 'python')
}

function ensureWorker() {
  if (worker) return
  worker = spawn(pythonPath(), [path.join(guiRoot, 'python', 'worker.py'), '--root', root], {
    cwd: root,
    stdio: ['pipe', 'pipe', 'pipe'],
  })
  let buffered = ''
  worker.stdout.setEncoding('utf8')
  worker.stdout.on('data', (chunk) => {
    buffered += chunk
    let newline
    while ((newline = buffered.indexOf('\n')) >= 0) {
      const line = buffered.slice(0, newline)
      buffered = buffered.slice(newline + 1)
      if (!line.trim()) continue
      try {
        const response = JSON.parse(line)
        const slot = pending.get(response.id)
        if (slot) {
          pending.delete(response.id)
          response.error ? slot.reject(new Error(response.error)) : slot.resolve(response.result)
        }
      } catch (error) {
        console.error('Invalid inspection worker response', line, error)
      }
    }
  })
  worker.stderr.on('data', (chunk) => console.error(`[inspection-python] ${chunk}`))
  worker.on('exit', (code) => {
    const error = new Error(`Inspection worker stopped (exit ${code})`)
    for (const slot of pending.values()) slot.reject(error)
    pending.clear()
    worker = undefined
  })
}

function callWorker(command, payload = {}) {
  ensureWorker()
  const id = nextId++
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject })
    worker.stdin.write(`${JSON.stringify({ id, command, ...payload })}\n`)
  })
}

async function analyze(filePath) {
  const result = await callWorker('analyze', { path: filePath })
  const bytes = await readFile(filePath)
  const ext = path.extname(filePath).toLowerCase()
  const mime = ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : ext === '.bmp' ? 'image/bmp' : 'image/png'
  return { ...result, imageUrl: `data:${mime};base64,${bytes.toString('base64')}` }
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1600,
    height: 1000,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#0b0e12',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false },
  })
  win.maximize()
  if (process.env.VITE_DEV_SERVER_URL) win.loadURL(process.env.VITE_DEV_SERVER_URL)
  else win.loadFile(path.join(guiRoot, 'dist', 'index.html'))
}

ipcMain.handle('inspection:choose-image', async () => {
  const result = await dialog.showOpenDialog({
    title: 'Open inspection image',
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'bmp', 'tif', 'tiff'] }],
  })
  return result.canceled ? null : result.filePaths[0]
})
ipcMain.handle('inspection:analyze', (_event, filePath) => analyze(filePath))
ipcMain.handle('inspection:relationship', (_event, request) => callWorker('relationship', { request }))
ipcMain.handle('inspection:default-sample', () => path.join(guiRoot, 'demo-data', 'drilled_plate.png'))

app.whenReady().then(() => {
  createWindow()
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow() })
})
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
app.on('before-quit', () => { if (worker) worker.kill() })

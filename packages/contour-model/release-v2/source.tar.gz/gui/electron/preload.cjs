const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('inspection', {
  chooseImage: () => ipcRenderer.invoke('inspection:choose-image'),
  analyze: (path) => ipcRenderer.invoke('inspection:analyze', path),
  measureRelationship: (request) => ipcRenderer.invoke('inspection:relationship', request),
  defaultSample: () => ipcRenderer.invoke('inspection:default-sample'),
})

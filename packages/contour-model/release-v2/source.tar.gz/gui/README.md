# Telecentric Inspector GUI prototype

Electron + Vite + React desktop prototype for the inspection pipeline. The app
opens maximized (ordinary resizable window, not macOS full-screen), loads a fresh
synthetic test image, runs the release-v2 semantic model automatically, and keeps
all geometric measurement in the Python `inspection-measurement` package.

## Run

```bash
cd gui
npm install
uv venv .venv --python 3.13
uv pip install --python .venv/bin/python \
  -e '../pae[test]' -e '../measurement[test,image]' \
  -e '../contour-model[test,bridge]' -e '../synthetic-shapes[test]'
npm run demo-data
npm run dev
```

Use `npm start` after `npm run build`. Set `INSPECTION_PYTHON` to select another
compatible interpreter instead of `gui/.venv/bin/python`.

## Interaction

- Hover a colored contour for feature identity and its automatic measurements.
- Click in the pointer tool to pin/unpin the feature card. Escape clears every
  pinned selection and any in-progress relationship selection.
- Show/hide automatic labels and their size, form, radii, and orientation groups
  from the right panel.
- Choose distance or angle in the left rail, click two features, configure the
  anchors/statistic, and add the result. Distance cards report minimum, maximum,
  and arc-length-sampled average. Angle accepts fitted line features only.
- Open image supports ordinary grayscale/color files. Synthetic demo images use
  their saved exact generated contour observations; arbitrary files run the PAE
  subpixel silhouette extractor first.

## Architecture

The sandboxed renderer talks only to a narrow preload API. Electron owns a
persistent JSON-lines Python worker. That worker performs PAE extraction, invokes
`release-v2/model.pt`, and passes all primitive and relationship requests to
`inspection_measurement.evaluate`. The renderer only draws returned support,
measurement witnesses, and report values.

`npm run demo-data` regenerates four 1600×900 renderings from `synthetic-shapes`:
drilled plate, stepped shaft, grooved pin, and slotted bracket. The files and a
small provenance manifest are written to `gui/demo-data`.

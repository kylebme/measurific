"""Render measured support and dimension witnesses with a separate report legend."""
import numpy as np
from PIL import Image, ImageDraw, ImageFont


def annotate(image, report, *, level=4):
    array = np.asarray(image)
    if array.dtype != np.uint8 or array.ndim not in (2, 3) or (array.ndim == 3 and array.shape[2] not in (3, 4)):
        raise ValueError('Annotation image must be uint8 grayscale, RGB or RGBA')
    source = Image.fromarray(array).convert('RGB')
    visible = {f['id'] for f in report['features'] if f.get('level', 1) <= level}
    rows = [m for m in report['measurements'] if any(ref in visible for ref in m['feature_refs'])]
    canvas = Image.new('RGB', (source.width+580, max(source.height, 72+len(rows)*42)), '#111820')
    canvas.paste(source, (0, 0))
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default(size=14)
    colors = ['#00c2ff', '#ffb347', '#d78aff', '#30df9b', '#ff7999']
    label_boxes = []
    for i, feature in enumerate(report['features']):
        if feature['id'] not in visible or feature['status'] != 'fitted':
            continue
        color = colors[i % len(colors)]
        for q, closed in zip(feature.get('support', []), feature.get('closed', [])):
            vertices = [tuple(p) for p in q]
            if closed:
                vertices.append(vertices[0])
            draw.line(vertices, fill=color, width=1)
        geom = feature['geometry']
        if 'center' in geom:
            x, y = geom['center']
            draw.line([(x-4, y), (x+4, y)], fill=color, width=1)
            draw.line([(x, y-4), (x, y+4)], fill=color, width=1)
            label_x, label_y = x+5, y+4
            for _ in range(len(label_boxes)+1):
                box = draw.textbbox((label_x, label_y), feature['id'], font=font)
                if not any(box[0] < b[2]+3 and box[2]+3 > b[0] and box[1] < b[3]+3 and box[3]+3 > b[1] for b in label_boxes):
                    break
                label_y += 18
            label_boxes.append(box)
            draw.text((label_x, label_y), feature['id'], font=font, fill=color, stroke_width=1, stroke_fill='#111820')
    x = source.width+14
    draw.text((x, 14), 'Contour measurements | pixels', fill='white', font=font)
    draw.text((x, 35), 'Image coordinates: x right, y down', fill='#a8b9c9', font=font)
    for i, m in enumerate(rows):
        color = '#ff6575' if m['status'] != 'measured' or m.get('pass_fail') == 'fail' else '#70e3ac'
        if 'witness' in m:
            draw.line([tuple(p) for p in m['witness']], fill=color, width=2)
            for px, py in m['witness']:
                draw.ellipse((px-2, py-2, px+2, py+2), fill=color)
        value = m['value']
        text = f'{value:.6g} {m["units"]}' if isinstance(value, (float, int)) else str(value)
        if m['status'] != 'measured':
            text = m.get('reason', m['status'])
        elif m.get('pass_fail'):
            text += '  '+m['pass_fail'].upper()
        y = 66+i*42
        draw.text((x, y), m['id'][:70], fill='white', font=font)
        draw.text((x, y+18), text[:70], fill=color, font=font)
    return canvas

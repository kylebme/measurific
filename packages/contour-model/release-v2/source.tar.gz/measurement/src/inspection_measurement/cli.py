"""Programmatic inputs also have a small file-based command-line wrapper."""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image
from . import Contours, inspect_image


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('image', type=Path)
    parser.add_argument('request', type=Path)
    parser.add_argument('output', type=Path, help='Output directory')
    parser.add_argument('--contours', type=Path, help='Saved native contour JSON (otherwise extract with PAE)')
    parser.add_argument('--threshold', type=float)
    parser.add_argument('--pae-threshold', type=float, default=25.)
    parser.add_argument('--polarity', choices=['dark-on-light', 'light-on-dark'], default='dark-on-light')
    args = parser.parse_args(argv)
    request = json.loads(args.request.read_text())
    contours = Contours.from_dict(json.loads(args.contours.read_text())) if args.contours else None
    image = np.asarray(Image.open(args.image).convert('L'))
    report, annotated, contours = inspect_image(image, request, contours=contours,
        extraction={'threshold': args.threshold, 'pae_threshold': args.pae_threshold, 'polarity': args.polarity})
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output/'results.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
    (args.output/'contours.json').write_text(json.dumps(contours.to_dict(), indent=2)+'\n')
    annotated.save(args.output/'annotated.png')
    print(json.dumps(report['summary']))
    return 1 if report['summary']['failed_or_unavailable'] or report['summary']['tolerance_failures'] else 0

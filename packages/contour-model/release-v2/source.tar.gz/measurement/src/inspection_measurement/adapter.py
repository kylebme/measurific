"""Use threshold topology to order original PAE samples, without raster fallback."""
import numpy as np
from scipy.spatial import cKDTree
from shapely.geometry import Polygon
from .contours import Contours


def contours_from_image(image, *, edges=None, threshold=None, polarity='dark-on-light',
                        pae_threshold=25., min_area=8., search_radius=3,
                        max_match_distance=2., max_gap=3.):
    """Return (Contours, diagnostics). Threshold edges only establish connectivity.

    Every output vertex is an unmodified PAE observation. Incomplete or ambiguous
    loops fail explicitly. Closed contours touching the image border are rejected.
    """
    import cv2
    gray = np.asarray(image)
    if gray.ndim != 2 or gray.dtype != np.uint8:
        raise ValueError('Image adapter currently requires a grayscale uint8 image')
    if polarity not in ('dark-on-light', 'light-on-dark'):
        raise ValueError('Unsupported image polarity')
    if not np.isfinite([min_area, max_match_distance, max_gap]).all() or min_area < 0 or min(max_match_distance, max_gap) <= 0:
        raise ValueError('Invalid contour adapter thresholds')
    if threshold is None:
        threshold = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)[0]
    if not np.isfinite(threshold) or not 0 <= threshold <= 255:
        raise ValueError('threshold must be in [0,255]')
    material = gray < threshold if polarity == 'dark-on-light' else gray > threshold
    if material[0].any() or material[-1].any() or material[:, 0].any() or material[:, -1].any():
        raise ValueError('Material touches image border; closed topology is not observable')
    raster, hierarchy = cv2.findContours(material.astype(np.uint8)*255, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
    selected = [i for i, q in enumerate(raster) if abs(cv2.contourArea(q)) >= min_area and len(q) >= 3]
    if not selected:
        raise ValueError('No complete silhouette contours')
    seeds = [raster[i][:, 0].astype(float) for i in selected]
    if edges is None:
        from pae import detect_silhouette
        edges = detect_silhouette(gray, pae_threshold=pae_threshold,
                                  silhouette_threshold=float(threshold), polarity=polarity,
                                  min_area=min_area, search_radius=search_radius)
    observed = np.c_[edges.x, edges.y].astype(float)
    normals = np.c_[edges.nx, edges.ny].astype(float)
    if len(observed) == 0 or not np.isfinite(observed).all() or not np.isfinite(normals).all():
        raise ValueError('No finite PAE edge observations')
    lengths = np.array([len(q) for q in seeds])
    offsets = np.r_[0, np.cumsum(lengths)]
    starts = np.concatenate(seeds)
    ends = np.concatenate([np.roll(q, -1, axis=0) for q in seeds])
    segment = ends-starts
    segment_length = np.linalg.norm(segment, axis=1)
    owner = np.repeat(np.arange(len(seeds)), lengths)
    # Query enough local raster segments to project onto both sides of corners.
    tree = cKDTree((starts+ends)/2)
    _, candidates = tree.query(observed, k=min(12, len(starts)))
    if candidates.ndim == 1:
        candidates = candidates[:, None]
    delta = segment[candidates]
    t = np.clip(np.sum((observed[:, None]-starts[candidates])*delta, axis=2)/segment_length[candidates]**2, 0, 1)
    projections = starts[candidates]+t[:, :, None]*delta
    distances = np.linalg.norm(projections-observed[:, None], axis=2)
    tangent = delta/segment_length[candidates, None]
    # Unsigned because outer and hole rings have opposite raster traversal.
    alignment = np.abs(tangent[:, :, 0]*normals[:, None, 1]-tangent[:, :, 1]*normals[:, None, 0])
    score = np.where(alignment >= .35, distances, np.inf)
    choice = np.argmin(score, axis=1)
    rows = np.arange(len(observed))
    best = candidates[rows, choice]
    distance = score[rows, choice]
    eligible = distance <= max_match_distance
    # A near-tie to a different ring is not a reliable ring assignment.
    competing = np.min(np.where(owner[candidates] != owner[best, None], score, np.inf), axis=1)
    ambiguous = eligible & (competing <= distance+.2)
    if ambiguous.any():
        raise ValueError('Ambiguous PAE correspondence between nearby silhouette rings')
    ordered, source_ids, metadata = [], [], []
    for i, seed in enumerate(seeds):
        ids = np.flatnonzero(eligible & (owner[best] == i))
        if len(ids) < 6:
            raise ValueError(f'Ring {i} has insufficient PAE support')
        arc = np.r_[0, np.cumsum(segment_length[offsets[i]:offsets[i+1]])]
        s = arc[best[ids]-offsets[i]]+t[ids, choice[ids]]*segment_length[best[ids]]
        order = np.argsort(s, kind='stable')
        ids, s = ids[order], s[order]
        # Two distinct observations at the same ordering position are ambiguous;
        # exact duplicate coordinates can be safely collapsed.
        q = observed[ids]
        keep = np.r_[True, np.linalg.norm(np.diff(q, axis=0), axis=1) > 1e-10]
        ids, s = ids[keep], s[keep]
        q = observed[ids]
        gaps = np.diff(np.r_[s, s[0]+arc[-1]])
        euclidean_gap = np.linalg.norm(np.roll(q, -1, axis=0)-q, axis=1)
        if gaps.max() > max_gap or euclidean_gap.max() > max_gap:
            raise ValueError(f'Ring {i} has missing PAE support (gap > {max_gap:g} px)')
        if not Polygon(q).is_valid:
            raise ValueError(f'Ring {i} PAE ordering is self-intersecting')
        depth, parent = 0, int(hierarchy[0, selected[i], 3])
        while parent >= 0:
            depth += 1
            parent = int(hierarchy[0, parent, 3])
        # Image coordinates: outer rings positive shoelace area, holes negative.
        signed_area = np.sum(q[:, 0]*np.roll(q[:, 1], -1)-q[:, 1]*np.roll(q[:, 0], -1))
        if (signed_area < 0) != bool(depth % 2):
            q, ids = q[::-1], ids[::-1]
        ordered.append(q)
        source_ids.extend(ids.tolist())
        metadata.append({'path': i, 'depth': depth, 'is_hole': bool(depth % 2),
                         'point_count': len(q), 'largest_ordering_gap': float(gaps.max())})
    # Preserve nesting and reject crossing contours after subpixel association.
    polys = [Polygon(q) for q in ordered]
    for i in range(len(polys)):
        for j in range(i):
            if polys[i].boundary.intersects(polys[j].boundary):
                raise ValueError('Subpixel rings cross or touch')
            expected = Polygon(seeds[i]).contains(Polygon(seeds[j]))
            reverse = Polygon(seeds[j]).contains(Polygon(seeds[i]))
            if polys[i].contains(polys[j]) != expected or polys[j].contains(polys[i]) != reverse:
                raise ValueError('PAE association changed ring nesting')
    contours = Contours(np.concatenate(ordered), np.r_[0, np.cumsum([len(q) for q in ordered])])
    return contours, {'method': 'threshold_topology_ordered_original_pae_samples',
                      'threshold': float(threshold), 'rings': metadata,
                      'pae_source_indices': source_ids, 'input_edge_count': len(observed),
                      'unused_edge_count': len(observed)-len(source_ids), 'interpolated_point_count': 0}

"""Versioned JSON requests, independent feature fitting and tolerance evaluation."""
from copy import deepcopy
import json
import numpy as np
from .contours import Contours, select, integer
from .geometry import Geometry, fit_geometry
from .operators import measure, OPERATORS, scalar

COMPOUNDS = {'width', 'angle', 'groove', 'notch', 'step', 'taper', 'pattern'}
ROUTES = {'profile': 'contour', 'external_profile': 'contour', 'polygon': 'polygon',
          'rounded_profile': 'contour', 'thread_pitch': 'repeated_profile',
          'tab': 'contour', 'groove': 'contour', 'notch': 'contour'}
DEFAULTS = {
    'line': ['length', 'orientation', 'straightness', 'rms_residual'],
    'circle': ['center', 'least_squares_diameter', 'circularity_ls'],
    'arc': ['radius', 'angular_span', 'arc_length', 'rms_residual'],
    'ellipse': ['center', 'major_axis', 'minor_axis', 'orientation', 'rms_residual'],
    'elliptical_arc': ['major_axis', 'minor_axis', 'angular_span', 'arc_length'],
    'slot': ['width', 'overall_length', 'end_radius', 'orientation', 'rms_residual'],
    'rounded_rectangle': ['width', 'overall_length', 'corner_radius', 'rms_residual'],
    'polygon': ['area', 'perimeter', 'centroid'],
    'contour': ['length'], 'freeform': ['length'], 'repeated_profile': ['length'],
}


def jsonable(value):
    if isinstance(value, np.ndarray):
        # Numeric arrays already know every element's type. Check finiteness in
        # one pass and let NumPy convert them without Python recursion per pixel.
        if value.dtype.kind in 'biu':
            return value.tolist()
        if value.dtype.kind == 'f' and value.dtype.itemsize <= 8:
            if not np.isfinite(value).all():
                raise ValueError('Nonfinite result cannot be serialized')
            return value.tolist()
        return jsonable(value.tolist())
    if isinstance(value, np.generic):
        return jsonable(value.item())
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    if isinstance(value, float) and not np.isfinite(value):
        raise ValueError('Nonfinite result cannot be serialized')
    return value


def indexed(items, name):
    if not isinstance(items, list):
        raise ValueError(f'{name} must be a list')
    out = {}
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get('id'), str) or not item['id']:
            raise ValueError(f'Every {name} entry requires a nonempty string id')
        if item['id'] in out:
            raise ValueError(f'Duplicate {name} id: {item["id"]}')
        out[item['id']] = item
    return out


def normalize(request, contours):
    req = deepcopy(request)
    if not isinstance(req, dict):
        raise ValueError('Request must be an object')
    primitive_prediction=(req.get('schema_version')==2 and req.get('label_version')=='primitives-compounds-v1')
    if (req.get('schema_version', 1) != 1 and not primitive_prediction) or req.get('units', 'px') != 'px':
        raise ValueError('Expected schema_version=1 or primitive prediction schema_version=2, and units=px')
    if req.get('coordinate_system', 'image') != 'image':
        raise ValueError('Coordinates must be image pixels (+y down)')
    if 'coordinate_hash' in req and req['coordinate_hash'] != contours.coordinate_hash:
        raise ValueError('Request contour hash mismatch: edge selections refer to different observations')
    features = indexed(req.get('features', [])+(req.get('compound_features', []) if primitive_prediction else []), 'features')
    # Overrides deliberately replace specified fields, not whole model documents.
    overrides = indexed(req.get('overrides', []), 'overrides')
    for ident, override in overrides.items():
        if ident not in features:
            raise ValueError(f'Override refers to unknown feature {ident}')
        if override.get('source') != 'user':
            raise ValueError('Overrides require source=user')
        f = features[ident]
        if 'selection' in override:
            f.pop('raw_edge_indices', None)
            f.pop('contour_spans', None)
        f.update(override)
    for f in features.values():
        if 'level' in f and integer(f['level'], 'level', 1) > 4:
            raise ValueError('Feature reporting level must be between 1 and 4')
        if f.get('units', 'px') != 'px':
            raise ValueError('Feature units must be pixels')
        f.setdefault('source', 'model' if 'measurement_route' in f else 'user')
        if f['source'] not in ('user', 'model'):
            raise ValueError('Feature source must be model or user')
        if 'type' not in f:
            route = f.get('measurement_route', 'contour')
            f['type'] = ROUTES.get(route, route)
        if 'selection' not in f and 'raw_edge_indices' in f:
            f['selection'] = {'edge_indices': f['raw_edge_indices']}
        elif 'selection' not in f and 'contour_spans' in f:
            f['selection'] = {'spans': f['contour_spans']}
    req['features'] = list(features.values())
    if 'measurements' not in req:
        req['measurements'] = [{'id': f'{f["id"]}.{op}', 'operator': op, 'feature_refs': [f['id']]}
                               for f in features.values() for op in DEFAULTS.get(f['type'], ['compound'])]
    indexed(req['measurements'], 'measurements')
    return req


def tolerance_evaluation(measured, request):
    out = {'nominal_value': request.get('nominal_value'), 'deviation': None,
           'tolerance': request.get('tolerance'), 'pass_fail': None}
    nominal = request.get('nominal_value')
    tol = request.get('tolerance')
    if nominal is None and tol is None:
        return out
    value = measured['value']
    if isinstance(value, (list, dict, np.ndarray)) or not np.isscalar(value):
        raise ValueError('Numeric tolerance checks require a scalar result')
    if nominal is not None:
        nominal = scalar(nominal, 'nominal_value')
        out['deviation'] = value-nominal
    if tol is not None:
        if not isinstance(tol, dict) or set(tol)-{'lower', 'upper'} or not tol:
            raise ValueError('tolerance requires lower and/or upper absolute value bounds')
        low = scalar(tol['lower'], 'lower') if 'lower' in tol else -np.inf
        high = scalar(tol['upper'], 'upper') if 'upper' in tol else np.inf
        if low > high:
            raise ValueError('Tolerance lower bound exceeds upper bound')
        out['pass_fail'] = 'pass' if low <= value <= high else 'fail'
    return out


def evaluate(contours, request):
    """Return JSON-safe results. Structural request errors raise ValueError;
    local selection/fit/measurement failures become explicit result records.
    """
    if not isinstance(contours, Contours):
        contours = Contours.from_dict(contours)
    req = normalize(request, contours)
    definitions = indexed(req['features'], 'features')
    geometries, records, active = {}, {}, set()

    def build(ident):
        if ident in records:
            return geometries.get(ident)
        if ident not in definitions:
            raise ValueError(f'Unknown feature reference: {ident}')
        if ident in active:
            raise ValueError('Cyclic compound feature membership')
        f = definitions[ident]
        record = {k: deepcopy(f[k]) for k in ('id', 'type', 'source', 'semantic', 'confidence', 'parent', 'level') if k in f}
        record['selection_confidence'] = f.get('confidence')
        if f.get('status') == 'abstain' and not (f.get('source') == 'user' and f.get('accept') is True):
            records[ident] = {**record, 'status': 'abstain', 'reason': 'Model selection requires explicit user acceptance'}
            return None
        active.add(ident)
        try:
            if f['type'] in COMPOUNDS:
                if not isinstance(f.get('members'), list) or not f['members']:
                    raise ValueError('Compound geometry needs member feature IDs')
                if len(set(f['members'])) != len(f['members']):
                    raise ValueError('Duplicate compound members')
                members = [build(member) for member in f['members']]
                if any(m is None for m in members):
                    raise ValueError('Compound member unavailable')
                g = Geometry(ident, f['type'], members=members)
                g.values = {'method': 'explicit_member_composition'}
                record['members'] = f['members']
            else:
                if 'selection' not in f:
                    raise ValueError('Feature requires observed contour selection')
                runs, closed, ids = select(contours, f['selection'])
                if 'raw_edge_indices' in f and 'contour_spans' in f:
                    _, _, span_ids = select(contours, {'spans': f['contour_spans']})
                    if not np.array_equal(ids, span_ids):
                        raise ValueError('Model raw edge indices and contour spans disagree')
                g = fit_geometry(Geometry(ident, f['type'], runs, closed))
                record.update(edge_indices=ids, support=runs, closed=closed)
            if 'max_rms_residual' in f:
                limit = scalar(f['max_rms_residual'], 'max_rms_residual', True)
                if 'rms_residual' not in g.values or g.values['rms_residual'] > limit:
                    raise ValueError('Geometry exceeds requested RMS fit residual limit')
            geometries[ident] = g
            record.update(status='fitted', geometry=g.values)
        except (ValueError, KeyError, TypeError, np.linalg.LinAlgError) as error:
            record.update(status='fit_failed', reason=str(error))
        finally:
            active.remove(ident)
        records[ident] = jsonable(record)
        return geometries.get(ident)

    for ident in definitions:
        build(ident)
    measurements = []
    for m in req['measurements']:
        base = {'id': m['id'], 'operator': m.get('operator'), 'feature_refs': m.get('feature_refs', []),
                'status': 'failed', 'value': None, 'pass_fail': None,
                'uncertainty': None, 'uncertainty_status': 'not_evaluated'}
        try:
            if m.get('operator') not in OPERATORS:
                raise ValueError(f'Unsupported operator: {m.get("operator")}')
            refs = m.get('feature_refs')
            if not isinstance(refs, list) or not refs or not all(isinstance(x, str) for x in refs):
                raise ValueError('feature_refs must be a nonempty list of IDs')
            if any(ref not in records or records[ref]['status'] != 'fitted' for ref in refs):
                base['status'] = 'unavailable'
                raise ValueError('Referenced feature is unknown, abstained, or failed fitting')
            params = m.get('params', {})
            if not isinstance(params, dict):
                raise ValueError('params must be an object')
            if m['operator'] == 'compound' and len(refs) == 1:
                params = {**definitions[refs[0]].get('params', {}), **params}
            measured = jsonable(measure(m['operator'], [geometries[r] for r in refs], params))
            checked = tolerance_evaluation(measured, m)
            base.update(measured, **checked, status='measured')
        except (ValueError, KeyError, TypeError, IndexError, np.linalg.LinAlgError) as error:
            base['reason'] = str(error)
        measurements.append(jsonable(base))
    report = {'schema_version': 1, 'units': 'px', 'coordinate_system': 'image',
              'coordinate_hash': contours.coordinate_hash,
              'features': [records[i] for i in definitions], 'measurements': measurements,
              'summary': {'measured': sum(m['status'] == 'measured' for m in measurements),
                          'failed_or_unavailable': sum(m['status'] != 'measured' for m in measurements),
                          'tolerance_failures': sum(m['pass_fail'] == 'fail' for m in measurements)}}
    json.dumps(report, allow_nan=False)
    return report

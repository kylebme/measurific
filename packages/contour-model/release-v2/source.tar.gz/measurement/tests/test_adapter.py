from types import SimpleNamespace
import numpy as np
import pytest
from inspection_measurement import contours_from_image, inspect_image, Contours
from inspection_shapes.geometry import generate
from inspection_shapes.render import Camera, render


@pytest.fixture(scope='module')
def washer():
    part = generate('washer', 561, severity=0)
    ppm = 150/np.ptp(part.rings[0].actual, axis=0).max()
    camera = Camera(width=240, height=220, supersample=4, pixels_per_mm=ppm,
                    translation_x=120, translation_y=110, sigma_px=.8,
                    read_noise_dn=0, prnu=0, electrons_per_dn=100000)
    image = render(part, camera, seed=14)[0]['image']
    return image, part, camera


def test_renderer_pae_roundtrip_and_measurement(washer):
    image, part, camera = washer
    from pae import detect_silhouette
    edges = detect_silhouette(image, pae_threshold=25, silhouette_threshold=120, search_radius=3, min_area=8)
    c, diagnostics = contours_from_image(image, edges=edges, threshold=120)
    assert len(c.closed) == 2
    assert sorted(r['is_hole'] for r in diagnostics['rings']) == [False, True]
    original = np.c_[edges.x, edges.y]
    np.testing.assert_array_equal(c.xy, original[diagnostics['pae_source_indices']])
    assert diagnostics['interpolated_point_count'] == 0
    outer = next(r['path'] for r in diagnostics['rings'] if not r['is_hole'])
    req = {'features': [{'id': 'outer', 'type': 'circle', 'selection': {'path': outer}}]}
    report, annotated, _ = inspect_image(image, req, contours=c)
    assert report['summary']['failed_or_unavailable'] == 0
    diameter = next(m['value'] for m in report['measurements'] if m['operator'] == 'least_squares_diameter')
    # synthetic-shapes is a polygon/raster renderer, with non-metrological raster bias.
    assert abs(diameter-150) < 1
    assert annotated.width > image.shape[1]
    assert annotated.height >= image.shape[0]
    np.testing.assert_array_equal(Contours.from_dict(c.to_dict()).xy, c.xy)
    # Re-extraction is deterministic: JSON edge selections remain stable.
    again, _ = contours_from_image(image, threshold=120)
    assert again.coordinate_hash == c.coordinate_hash


def test_missing_observations_rejected(washer):
    image, _, _ = washer
    from pae import detect_silhouette
    edges = detect_silhouette(image, pae_threshold=25, silhouette_threshold=120)
    keep = ~((edges.x > 100) & (edges.x < 125) & (edges.y < 60))
    missing = SimpleNamespace(**{k: getattr(edges, k)[keep] for k in ('x', 'y', 'nx', 'ny')})
    with pytest.raises(ValueError, match='missing PAE support'):
        contours_from_image(image, edges=missing, threshold=120)


def test_polarity_and_border_rejection(washer):
    image, _, _ = washer
    c, info = contours_from_image(255-image, threshold=135, polarity='light-on-dark')
    assert len(c.closed) == 2
    clipped = image.copy()
    clipped[0, 100] = 0
    with pytest.raises(ValueError, match='border'):
        contours_from_image(clipped, threshold=120)


def test_cli_saved_contours(tmp_path):
    from PIL import Image
    from inspection_measurement.cli import main
    import json
    image = tmp_path/'input.png'
    Image.new('L', (100, 100), 220).save(image)
    c = Contours([[10, 10], [50, 10]], [0, 2], [False])
    contour_file = tmp_path/'c.json'
    contour_file.write_text(json.dumps(c.to_dict()))
    req = tmp_path/'request.json'
    req.write_text(json.dumps({'features': [{'id': 'line', 'type': 'line', 'selection': {'path': 0}}]}))
    output = tmp_path/'output'
    assert main([str(image), str(req), str(output), '--contours', str(contour_file)]) == 0
    report = json.loads((output/'results.json').read_text())
    assert report['summary']['measured'] == 4
    assert (output/'annotated.png').exists()

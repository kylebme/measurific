# Pixel contour measurement

Standalone, CPU-only, non-ML Python module. The core accepts **contours + a JSON
measurement request**; the image wrapper extracts PAE contours and also produces
an annotated image. Distances are in pixels, angles in degrees, areas in px², and
curvature in 1/px. Coordinates are image coordinates: x right, y down, integer
pixel centers. No calibration is applied. Existing project folders are unchanged.

## Install and run

From the repository root:

```bash
python3 -m venv measurement/.venv
measurement/.venv/bin/python -m pip install -e './pae' -e './measurement[image,test]'
measurement/.venv/bin/python -m inspection_measurement input.png request.json measurement/outputs/run
```

With uv, use `uv venv measurement/.venv` followed by
`uv pip install --python measurement/.venv/bin/python -e ./pae -e './measurement[image,test]'`.
Install only `./measurement` for precomputed contours; PAE and OpenCV are optional
image dependencies. The measurement package never imports Torch or runs a model.

The CLI writes `results.json`, `contours.json`, and `annotated.png`. Use
`--contours contours.json` to reuse exactly the same ordered observations,
`--threshold 120`, `--pae-threshold 25`, and `--polarity light-on-dark` as needed.
Exit status is 1 if any measurement is unavailable/failed or a tolerance fails;
otherwise 0. Output files are overwritten on a repeated run.

## Python API

```python
import json
import numpy as np
from PIL import Image
from inspection_measurement import inspect_image, evaluate

image = np.asarray(Image.open('input.png').convert('L'))
request = json.load(open('request.json'))
report, annotated, contours = inspect_image(
    image, request, extraction={'threshold': 120},
)
annotated.save('annotated.png')
with open('results.json', 'w') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)

# Reuse contours when changing only the measurement request.
report = evaluate(contours, request)
```

`inspect_image(image, request, contours=contours)` skips extraction.
`annotate(image, report, level=1..4)` filters displayed feature reporting levels;
all numeric results stay in JSON. The annotation adds a report panel beside the
image, colors selected contours, marks fitted centers, and draws distance witness
segments. It preserves the source image size and pixel coordinate frame.

## Contour contract

```json
{
  "units": "px", "coordinate_system": "image",
  "xy": [[10,10], [50,10], [50,30], [10,30]],
  "offsets": [0,4], "closed": [true]
}
```

`Contours(xy, offsets, closed=None)` accepts finite float64 `[N,2]` coordinates
and integer path offsets. Closure defaults to true. Rings omit a repeated closing
vertex and must be simple with nonzero area. Open paths need at least two vertices;
the final vertex has no outgoing edge. Consecutive duplicate vertices are rejected.
Different paths and disconnected selections are never implicitly connected.
`contours.to_dict()` and `Contours.from_dict(...)` round-trip this format.

### PAE conversion

`contours_from_image(image, edges=None, ...)` returns contours and diagnostics.
The image must be grayscale uint8. Thresholding establishes ordered outer/hole
boundaries; original PAE points are associated with nearby segments, checked for
normal compatibility, and sorted by projected contour position. `edges=` accepts
an existing PAE `Edges` object.

Every output vertex is an original PAE observation. Missing points are not replaced
by raster coordinates or interpolation. Diagnostics include source PAE indices,
ring nesting, largest ordering gaps and unused samples. Outer paths have positive
shoelace area in image coordinates; holes have negative area.

Defaults: Otsu threshold, dark-on-light, PAE threshold 25, min area 8 px², search
radius 3, maximum association distance 2 px, maximum support gap 3 px. Explicit
thresholds use the same strict comparison as PAE. Border-clipped material, missing
support, ambiguous ring assignments, crossing loops and changed nesting raise
`ValueError`. A failed extraction produces no measurements. This adapter targets
clear backlit silhouettes; ordering parameters require validation for real optics.
Multiple parts/nested islands are supported by the adapter, although the existing
transformer has narrower topology requirements.

## Request format

```json
{
  "schema_version": 1, "units": "px",
  "features": [
    {"id":"edge", "type":"line", "selection":{"region":{"box":[20,30,180,40]}}},
    {"id":"hole", "type":"circle", "selection":{"path":1}}
  ],
  "measurements": [
    {"id":"hole_to_line", "operator":"distance", "feature_refs":["edge","hole"],
     "nominal_value":20, "tolerance":{"lower":19.8,"upper":20.2}},
    {"id":"hole_size", "operator":"least_squares_diameter", "feature_refs":["hole"]}
  ]
}
```

[examples/manual_request.json](examples/manual_request.json) shows two lines, a
circle and a compound width. Its regions must be adjusted to the actual image;
it is an illustrative request, not an automatic part detector.

Feature and measurement IDs must be unique nonempty strings. Each primitive
requires `type` and exactly one selection form:

| Selection | Meaning |
| --- | --- |
| `{"path":0}` | All observed edges of a path |
| `{"edge_indices":[5,6,7]}` | Global outgoing-edge indices; endpoints included in fitting |
| `{"spans":[{"ring_index":0,"start_edge":90,"edge_count":20}]}` | Connected spans; wrapping allowed on closed paths |
| `{"region":{"box":[xmin,ymin,xmax,ymax]}}` | Both edge endpoints inside box |
| `{"region":{"circle":[cx,cy,r]}}` | Both edge endpoints inside disk |

Disconnected runs remain separate. Lines can fit pooled support; arcs, ellipses,
slots and single-profile operators require connected support. A region does not
automatically distinguish nearby edges: use tight regions or explicit spans.
`max_rms_residual` optionally rejects a fit beyond a caller-defined limit. All
observations are retained; there is no silent outlier removal.

Primitive/profile types: `line`, `circle`, `arc`, `ellipse`, `elliptical_arc`,
`freeform`, `contour`, `polygon`, `slot`, `rounded_rectangle`, `repeated_profile`.
Freeform geometry is an observed polyline without implicit smoothing. Slot fits
use a stadium; rounded rectangles use four equal corner radii. Other rounded
profiles and D profiles use a generic contour, nominal comparison, or constituents.

Compound types: `width`, `angle`, `step`, `taper`, `groove`, `notch`, `pattern`.
Their `members` reference existing feature IDs. Feature-level `params` supply
`compound` measurement defaults; measurement parameters override them. Metadata
`semantic`, `parent`, `confidence`, and `level` is preserved. Semantics never gate
user-defined geometry or determine dimensions.

Absent `measurements`, conservative per-type defaults are generated. An explicit
empty list requests fitting only. Parameter-dependent compound/repetition operators
need explicit parameters. Invalid request structure raises `ValueError`; local
fit/measurement failures become result records, leaving unrelated results usable.

## Transformer handoff and user overrides

Release-v2 prediction JSON is accepted directly when `units="px"`.
`measurement_route`, `raw_edge_indices`, and `contour_spans` are mapped to feature
descriptions. When both indices and spans exist they must agree. A supplied
`coordinate_hash` must match the original float64 coordinates and int64 offsets.
Stale selections are rejected. Hashing covers coordinates/offsets; native path
closure is carried separately.

Use the same pixel-valued arrays for both modules:

```python
raw = contours.model_arrays()
# In the orchestration process where the existing model is loaded:
prediction, _ = predict(model, raw, units='px')
report = evaluate(contours, prediction)
```

The model's legacy input key is `actual_xy_mm`, but `model_arrays()` places pixel
values in it; `units='px'` during inference is essential. There is no scale change,
y flip or reindexing. Recompute model predictions from these arrays if an earlier
prediction used y-up coordinates. The model handles its own traversal normalization.

Semantic groove/notch/rounded-profile routes map to generic contours: member roles
are not invented from labels. Repeated profiles may span disconnected sides;
select one monotone side and explicitly choose direction/prominence for repetition.
Do not include the old model's optional `--measure` results as this module's request
list. Replace that `measurements` field or omit it to generate new defaults.

Merge user overrides into the prediction document:

```json
{"overrides":[
  {"id":"feature_0001", "source":"user", "accept":true,
   "type":"line", "selection":{"region":{"box":[10,20,110,25]}}}
]}
```

Overrides replace specified fields. Replacing a selection removes old indices and
spans. Both `source="user"` and `accept=true` are required to use an abstained model
feature. Add new user features directly to `features` with unique IDs. Add explicit
measurement requests referring to either source or their combination.

## Measurement definitions

Each request has `operator`, ordered `feature_refs`, and optional `params`.
Results report the precise `method`. The registry is
`inspection_measurement.operators.OPERATORS`.

| Operators | Definition / parameters |
| --- | --- |
| `length`, `orientation` | Fitted line projected span and angle modulo 180°; generic length sums observed segments |
| `radius`, `least_squares_diameter` | Orthogonal least-squares circle/arc associated size |
| `arc_length`, `angular_span`, `chord_length`, `sagitta` | Associated circular-arc quantities, ordered span |
| `major_axis`, `minor_axis` | Full ellipse axis lengths from orthogonal fitting; ellipse orientation modulo 180° |
| `width`, `overall_length`, `end_radius`, `end_center_spacing` | Stadium fit |
| `width`, `overall_length`, `corner_radius` | Equal-radius rounded rectangle fit |
| `rms_residual`, `peak_to_valley_residual`, `max_abs_residual` | Fit diagnostics; ellipse residuals are unsigned distances |
| `straightness` | Minimum enclosing parallel strip, from convex-hull orientations |
| `circularity_ls` | Closed-circle radial range about LS center, **not** minimum-zone circularity |
| `area`, `perimeter`, `centroid` | One closed observed polygon; no automatic subtraction of other holes/paths |
| `extent` | Observed projection range along required `direction` |
| `center`, `x`, `y` | Associated center or closed-polygon area centroid |
| `center_distance`, `center_offset` | Center distance plus offset vector |
| `distance` | Line to circle center, or near-parallel line separation; `mode="segments"` uses observed finite segments |
| `minimum_separation` | Minimum observed segment distance, including segment interiors, with witness points |
| `distance_statistics` | Pairwise minimum, maximum, and average distance. `anchors=["edge"|"center", ...]` chooses observed edges or associated fitted centers; `statistic` selects the primary scalar result. The edge/edge minimum is continuous, while maximum/average are bounded uniform arc-length samples. |
| `angle` | Acute unoriented fitted-line angle, 0..90° |
| `parallelism`, `perpendicularity`, `angularity` | Angular deviations in degrees; angularity needs `nominal_angle`; not dimensional GD&T zones |
| `intersection` | Infinite fitted-line intersection / virtual sharp |
| `tangency` | Supporting line/circle or circle/circle gap; circle pairs use `mode="external"` or `"internal"`; not observed arc contact verification |
| `symmetry` | Two centers reflected about third reference, a datum line |
| `common_axis` | First reference datum line; remaining centers; max perpendicular offset |
| `true_position_2d` | Twice center offset from `nominal_center` in explicit `datum_origin`, `datum_x_direction` frame |
| `profile` | Observed vertices to `nominal_points` segments; optional `closed`; RMS, max, worst point, sampled Hausdorff |
| `curvature` | Signed three-point circumcircle curvature, one connected contour; noise-sensitive |
| `local_size` | Polygon sections normal to `direction` at `stations`, optional `origin`; rejects multiple material intervals |
| `wall_thickness` | Directed first-support vertex to second-support segment distance distribution; not medial-axis thickness |

Distance operators optionally accept `direction` for signed projection of their
witness vector. Two-line distance/step default to a 0.1° parallelism gate, adjustable
with `parallel_tolerance_degrees`. Nonparallel sides require width at explicit
stations or finite-segment distance.

Profile comparison uses supplied coordinates, with no automatic registration.
Closed nominal profiles report positive error outside and negative inside the
polygon, independent of winding. For a hole this is hole-region inward/outward,
not material excess/missing material. Open profiles return unsigned distances.
Hausdorff is sampled at supplied vertices in both directions, not a certified
continuous-curve extremum. Normal-to-CAD and registered minimum-zone comparison
are not implemented.

### Compounds

Use `operator="compound"` with one compound reference:

* `width`: two lines; `stations` are distances along the first line from its fitted
  center, default `[0]`. Return normal-to-first-line widths, min/max and flank angle.
* `taper`: same with at least two distinct stations; also signed width slope.
* `step`: separation of two near-parallel fitted lands.
* `angle`: acute included angle and virtual sharp of two lines.
* `groove` / `notch`: `roles` maps `opening`, `left`, `right`, optional `bottom` to
  line members. Return opening/bottom width, depth and flank angles. Without bottom,
  the flank intersection defines the V apex. Curved bottoms/transitions use separate
  arc constituents and primitive relationships.

Station and intersection evaluations use supporting lines and can extrapolate;
choose stations inside the observed region when extrapolation is inappropriate.
Member detection and design-intent inference are left to the caller/model/GUI.

### Patterns and repetitions

`pattern` accepts member feature references or one pattern compound:

* `domain="linear"`: required `direction`; sorted center spacing, mean/local pitch,
  local/cumulative errors and transverse range. Optional `nominal_pitch`; otherwise
  measured mean is the explicitly labeled reference.
* `domain="polar"`: optional center, otherwise fit from >=3 members; angular spacing
  including seam, indexing and radial/tangential errors. Optional
  `nominal_pitch_degrees`, `phase_degrees`, `nominal_radius`. Assumes a complete
  polar pattern; missing members appear as enlarged gaps.
* `domain="grid"`: required `direction` and integer `cells: [[column,row],...]`
  matching member order. Fit lattice origin/axes, pitches, orthogonality and residuals.
  Requires independently supported rows and columns.
* `domain="arbitrary"`: required `nominal_centers` matching member order; report
  error vectors and max position error, without matching/registration.

`repetition` uses one connected contour and required `prominence` in pixels:

* Linear: `domain="linear"`, required `direction`, one strictly monotone side.
  Uniform resampling and linear detrending precede extrema detection. Vertical,
  overhanging and pooled opposite-side profiles are rejected.
* Angular: `domain="angular"`, required `center`, single-valued radial profile.
  Closed profiles include the wrap gap and count seam extrema once.

Return resolved-extrema count, mean/local pitch, errors, positions, observed span,
profile height and grid resolution. Optional `extrema` is `maxima` or `minima`;
optional `nominal_pitch` defines pitch errors. At least three extrema are required.
Resolved extrema are not necessarily the intended tooth count. Thread pitch and
tooth pitch are generic visible-profile metrics; lead/helix, pitch diameter, module,
pressure angle and standards are not inferred.

## Results, tolerance checks, limits

Feature statuses: `fitted`, `fit_failed`, `abstain`. Measurement statuses:
`measured`, `failed`, `unavailable`. Failed results have no numeric value and cannot
pass. Reports retain observed support, fitted geometry, references, methods, units,
nominal/deviation, tolerance/pass-fail and error reasons.

Tolerance bounds are inclusive **absolute value limits**:
`{"lower":19.8,"upper":20.2}`. `nominal_value` separately defines deviation.
One-sided bounds are allowed. Vector/distribution results cannot be implicitly
reduced for tolerance evaluation. No guard band is applied. `uncertainty=null`
and `uncertainty_status="not_evaluated"` are deliberate; fitting residuals are
not a measurement uncertainty budget.

This is generic 2D metrology, not standardized GD&T certification. Deferred:
minimum-zone circularity, maximum-inscribed/minimum-circumscribed sizes, spline
fitting, CAD import/registration, standard thread/gear templates, automatic anomaly
classification, calibration and uncertainty estimation. No 3D quantity is claimed.

## Validation and reproducible demo

```bash
# From repository root; renderer is needed only for demo/integration tests.
uv pip install --python measurement/.venv/bin/python -e ./synthetic-shapes
cd measurement
.venv/bin/python -m pytest -q
```

Run the demo from the repository root:

```bash
PYTHONPATH=measurement/src:pae/src:synthetic-shapes/src \
  measurement/.venv/bin/python measurement/examples/synthetic_demo.py
```

`measurement/outputs/washer/` contains the input, request, contours, results,
annotation and projected analytic diameter references. Tests combine analytic
geometry expectations with synthetic-shapes image integration, stale-hash and
abstention checks, topology failures and missing-support rejection. The renderer's
polygon rasterization has dimensional bias: image tests establish integration,
not subpixel accuracy certification.

## CPU performance

For CPU timing results and the reproducible performance benchmark, see
[PERFORMANCE.md](PERFORMANCE.md). Optimized contour workloads measured 1.5–5.8×
faster using Python and the existing dependencies, with unchanged accuracy bounds.

## Dataset-v2 batch evaluation

The batch runner uses the existing contour-model Python environment (Torch) and
imports the measurement module directly. It selects 300 held-out parts with seeded,
family-balanced sampling, projects the stored actual contours to synthetic pixels,
runs release-v2, and evaluates default feature measurements plus a small set of
line/center relationships. This is a contour-input benchmark, not PAE extraction.

```bash
PYTHONPATH=measurement/src:contour-model/src:synthetic-shapes/src \
  contour-model/.venv/bin/python measurement/scripts/evaluate_dataset_v2.py \
  --source /media/T7Shield/inspection-contour-training/v2-expanded \
  --checkpoint contour-model/artifacts/release-v2/model.pt \
  --count 300 --split test --seed 20260907 \
  --output measurement/outputs/dataset-v2-test-300
```

Use a fresh output directory for each run. `selection.json` records IDs and source
hashes before inference. `REPORT.md`, `summary.json`, and `samples.jsonl` contain
coverage/failure statistics and matched reference-selection comparisons.
`index.html` links annotated previews for every sample. Each sample saves compressed
prediction/request/result/reference JSON, a lossless pixel contour NPZ, projection
parameters, rendered image, and an annotated preview of up to 12 measurements.

Reference comparisons apply the existing observable-surface grouping and match
accepted model leaf features to same-semantic references by arc-length IoU. Both
sets of dimensions are fitted to actual observed contours. Their differences
quantify selection sensitivity, not error against nominal dimensions. Nominal
coordinates and semantic truth never enter model inference or measurement fits.

`--reuse /path/prior-run` reuses matching saved model predictions and rendered images
while recomputing all measurements and reference fits. Missing predictions are
recomputed. The new manifest records reuse and current measurement-source hashes;
use this to verify a measurement fix without changing model selections. Run
`measurement/scripts/review_dataset_batch.py /path/run` with the same Python
source paths to add paired outlier images and `DIAGNOSTICS.md`.

## Independent ground-truth correctness evaluation

The dataset-v2 comparison above measures selector sensitivity. For measurement
correctness against independently known values, use the separate
[analytic benchmark](benchmarks/README.md). It constructs deterministic pixel parts
with recorded seeds, parameters, closed-form expected dimensions and nonzero form
errors. Both reference and model selections are scored against the same independent
truth, with missing measurements retained in the denominator. It also distinguishes
finite-polyline dimensions from smooth associated geometry.

"""Primitive selection and secondary compounds, using observed coordinates only."""
import hashlib
import numpy as np
import torch
from scipy.signal import find_peaks
from .sampling import prepare_adaptive
from .inference import (mapped_probabilities, mapped_boundary_events, runs,
                        describe_selection, observed_turn)

BASE_NAMES=['unlabeled','line','arc','circle','arbitrary_profile']
COMPOUND_NAMES=['none','full_round_slot','triangular_thread','trapezoidal_thread','tooth_profile']
LABEL_VERSION='primitives-compounds-v1'


def compatible_thread_sides(first,second,features,raw,edge_weights):
    """Opposite observed sides of one zone share a longitudinal interval.

    This only constrains grouping; it never assigns the compound's class.
    """
    supports=[]
    for members in (first,second):
        ids=np.concatenate([features[i]['raw_edge_indices'] for i in members])
        if len(ids)<4:return False
        q=raw[ids];w=edge_weights[ids];center=np.average(q,axis=0,weights=w)
        _,vectors=np.linalg.eigh(((q-center)*w[:,None]).T@(q-center)/w.sum())
        supports.append((q,center,vectors[:,-1]))
    (a,ca,axis),(b,cb,other)=supports
    if abs(np.dot(axis,other))<.96:return False
    ua,ub=a@axis,b@axis
    overlap=min(ua.max(),ub.max())-max(ua.min(),ub.min())
    if overlap<.75*max(np.ptp(ua),np.ptp(ub)):return False
    # Two neighboring subdivisions on the same side are not opposite faces.
    normal=np.array([-axis[1],axis[0]])
    separation=abs(np.dot(ca-cb,normal))
    return separation>max(np.ptp(a@normal),np.ptp(b@normal))


@torch.no_grad()
def predict(model,contours,tokens=None,threshold=.7,instances=True,units='mm'):
    if units not in ('mm','px'):raise ValueError('Units must be mm or px')
    prepared=prepare_adaptive(contours,version=model.config.sampling_version)
    device=next(model.parameters()).device
    out=model(torch.as_tensor(prepared.x,device=device),prepared.offsets,instances=instances)
    primary=mapped_probabilities(prepared,out['primary'].softmax(-1).cpu().numpy())
    compound=mapped_probabilities(prepared,out['compound'].softmax(-1).cpu().numpy())
    semantic=mapped_probabilities(prepared,out['semantic'].sigmoid().cpu().numpy())
    defect=mapped_probabilities(prepared,out['defect'].softmax(-1).cpu().numpy())
    token_boundary=out['boundary'].sigmoid().cpu().numpy()
    boundary=mapped_boundary_events(prepared,token_boundary)
    raw=np.asarray(contours['actual_xy_mm'],np.float64);offsets=np.asarray(contours['ring_offsets'],np.int64)
    classes=primary.argmax(-1);features=[];owner=np.full(len(raw),-1,int)
    edge_weights=np.empty(len(raw))

    def add_base(ids,cls):
        if not len(ids):return
        score=float(np.average(primary[ids,cls],weights=edge_weights[ids]))
        f={'id':f'base_{len(features)+1:05d}','semantic_id':int(cls),'semantic':BASE_NAMES[cls],
           'label_level':'base','confidence':score,'status':'accepted' if score>=threshold else 'abstain',
           'confidence_calibrated':False,'measurement_route':{1:'line',2:'arc',3:'circle',4:'profile'}[int(cls)],
           'raw_edge_indices':ids.tolist(),'contour_spans':describe_selection(ids,contours),
           'defect_edge_indices':ids[defect[ids,1:].max(-1)>.5].tolist(),
           'parent':'part','units':units,'fit_geometry':'original_observations',
           'grouping':'primitive_contour_span','boundary_search_regions':[]}
        owner[ids]=len(features);features.append(f)

    for ri,(lo,hi) in enumerate(zip(offsets[:-1],offsets[1:])):
        q=raw[lo:hi];lengths=np.linalg.norm(np.roll(q,-1,axis=0)-q,axis=1);edge_weights[lo:hi]=lengths
        arc=np.r_[0,np.cumsum(lengths)]
        avg=np.average(primary[lo:hi],axis=0,weights=lengths)
        if avg.argmax()==3 and np.mean(classes[lo:hi]==3)>.8:
            classes[lo:hi]=3;add_base(np.arange(lo,hi),3);continue
        # A partial circular span is an Arc, never a partial Circle instance.
        classes[lo:hi][classes[lo:hi]==3]=2
        tlo,thi=prepared.offsets[ri:ri+2]
        window=2*arc[-1]/(thi-tlo)
        turn=observed_turn(q,arc,np.arange(len(q)),window)
        # Learned events select neighborhoods; observed turning refines sharp corners.
        b=token_boundary[tlo:thi];peaks=find_peaks(np.tile(b,3),height=.5,distance=2)[0]
        peaks=peaks[(peaks>=len(b))&(peaks<2*len(b))]-len(b)
        cuts=[]
        for peak in peaks:
            support=prepared.overlap.getrow(tlo+int(peak)).indices
            support=support[(support>=lo)&(support<hi)]
            if not len(support):continue
            local=support-lo
            anchor=int(local[np.argmax(turn[local])]) if turn[local].max()>.12 else int(local[len(local)//2])
            cuts.append(anchor)
        for cls in np.unique(classes[lo:hi]):
            if cls==0:continue
            for run in runs(classes[lo:hi]==cls):
                positions={int(v):i for i,v in enumerate(run)}
                cut=sorted({positions[c] for c in cuts if c in positions})
                if len(run)==hi-lo and cut:
                    for a,b in zip(cut,cut[1:]+cut[:1]):
                        chosen=run[np.arange(a,b if b>a else b+len(run))%len(run)]
                        add_base(lo+chosen,int(cls))
                else:
                    cut=sorted({0,len(run),*[v for v in cut if 2<=v<len(run)-2]})
                    for a,b in zip(cut[:-1],cut[1:]):add_base(lo+run[a:b],int(cls))
    relations=[]
    for ri,(lo,hi) in enumerate(zip(offsets[:-1],offsets[1:])):
        o=owner[lo:hi]
        for i in np.flatnonzero(o!=np.roll(o,1)):
            left,right=o[(i-1)%len(o)],o[i]
            if min(left,right)<0:continue
            relations.append({'type':'contour_adjacency','feature_a':features[left]['id'],
                              'feature_b':features[right]['id'],'ring_index':ri,'at_edge':int(i)})
        perimeter=edge_weights[lo:hi].sum();radius=2*perimeter/(prepared.offsets[ri+1]-prepared.offsets[ri])
        arc=np.r_[0,np.cumsum(edge_weights[lo:hi])]
        for f in features:
            for span in f['contour_spans']:
                if span['ring_index']!=ri or span['closed_ring']:continue
                for at in (span['start_edge'],(span['start_edge']+span['edge_count'])%(hi-lo)):
                    distance=np.abs(arc[:-1]-arc[at]);distance=np.minimum(distance,perimeter-distance)
                    f['boundary_search_regions'].append({'ring_index':ri,'anchor_edge':int(at),
                        'search_radius':float(radius),'raw_edge_indices':(lo+np.flatnonzero(distance<=radius)).tolist()})
    compounds=[];assigned=set()
    def add_compound(members,cls,score,grouping):
        if not members:return
        ids=np.unique(np.concatenate([features[i]['raw_edge_indices'] for i in members])).astype(int)
        f={'id':f'compound_{len(compounds)+1:04d}','semantic_id':int(cls),'semantic':COMPOUND_NAMES[cls],
           'label_level':'compound','base_instance_ids':[features[i]['id'] for i in members],
           'confidence':float(score),'status':'accepted','confidence_calibrated':False,
           'classification_policy':'most_likely_compound','raw_edge_indices':ids.tolist(),
           'contour_spans':describe_selection(ids,contours),'parent':'part','units':units,
           'measurement_route':{1:'slot',2:'thread_pitch',3:'thread_pitch',4:'repeated_profile'}[int(cls)],
           'fit_geometry':'original_observations','grouping':grouping,
           'boundary_search_regions':[s for i in members for s in features[i]['boundary_search_regions']]}
        compounds.append(f);assigned.update(members)
        for i in members:relations.append({'type':'compound_membership','feature_a':features[i]['id'],'feature_b':f['id']})
    if instances:
        # Each opening supplies its own candidate; there is no slot count ceiling.
        for ri,(lo,hi) in enumerate(zip(offsets[:-1],offsets[1:])):
            if not prepared.hole[ri]:continue
            probs=np.average(compound[lo:hi],axis=0,weights=edge_weights[lo:hi])
            members=sorted(set(owner[lo:hi])-{ -1 })
            if probs.argmax()==1 and members and all(features[i]['semantic_id'] in (1,2) for i in members):
                add_compound(members,1,probs[1],'closed_slot_loop')
        query=out['query_class'].softmax(-1).cpu().numpy();qclasses=query.argmax(-1)
        candidates=[i for i in np.argsort(-query[:,2:].max(1)) if qclasses[i]>=2]
        masks=mapped_probabilities(prepared,out['query_masks'][candidates].sigmoid().cpu().numpy().T).T if candidates else []
        # Classify complete base instances, then associate complete contiguous
        # repeat regions. Query-mask erosion must not fragment a threaded zone.
        repeat_members=set()
        for i,f in enumerate(features):
            if i in assigned or f['semantic_id']==3:continue
            ids=f['raw_edge_indices'];cp=np.average(compound[ids],axis=0,weights=edge_weights[ids])
            if cp[2:].sum()>cp[:2].sum():repeat_members.add(i)
        components=[]
        for lo,hi in zip(offsets[:-1],offsets[1:]):
            for run in runs(np.isin(owner[lo:hi],list(repeat_members))):
                members=sorted(set(owner[lo+run]))
                components.append(members)
        info=[];supported=[]
        for members in components:
            ids=np.concatenate([features[i]['raw_edge_indices'] for i in members])
            cp=np.average(compound[ids],axis=0,weights=edge_weights[ids])
            cls=int(cp[2:].argmax()+2)
            # Repeated thread flanks need at least two pairs of constituent
            # spans on a side. Isolated corners are not repeat candidates,
            # even when their compound posterior is confident. This is a
            # detection constraint; detected compounds never abstain.
            if cls in (2,3) and sum(features[i]['semantic_id'] in (1,2) for i in members)<4:continue
            supported.append(members)
            info.append((cls,features[members[0]]['contour_spans'][0]['ring_index'],ids))
        components=supported
        for i,members in enumerate(components):
            if any(v in assigned for v in members):continue
            cls,ring,ids=info[i];partners=[]
            for j,other in enumerate(components):
                if j<=i or any(v in assigned for v in other):continue
                other_cls,other_ring,other_ids=info[j]
                if ring!=other_ring or (cls==4)!=(other_cls==4):continue
                if cls==4:
                    # Query evidence may bridge missed semantic intervals of a
                    # tooth profile, but never merges separate opening rings.
                    if any(np.average(mask[ids],weights=edge_weights[ids])>.5 and
                           np.average(mask[other_ids],weights=edge_weights[other_ids])>.5 for mask in masks):
                        partners.append(j)
                elif compatible_thread_sides(members,other,features,raw,edge_weights):partners.append(j)
            # A thread zone has at most one opposite contour-side partner.
            if cls!=4 and len(partners)>1:
                partners=sorted(partners,key=lambda j:np.linalg.norm(raw[ids].mean(0)-raw[info[j][2]].mean(0)))[:1]
            combined=members+[v for j in partners for v in components[j]]
            ids=np.concatenate([features[v]['raw_edge_indices'] for v in combined])
            probs=np.average(compound[ids],axis=0,weights=edge_weights[ids]);cls=int(probs[2:].argmax()+2)
            add_compound(combined,cls,probs[cls],'observed_repeat_regions_with_association')
    result={'schema_version':2,'label_version':LABEL_VERSION,'units':units,
            'coordinate_hash':hashlib.sha256(raw.tobytes()+offsets.tobytes()).hexdigest(),
            'part':{'id':'part','ring_count':len(offsets)-1,'ring_is_hole':prepared.hole.tolist(),
                    'bounds':[raw.min(0).tolist(),raw.max(0).tolist()]},
            'features':features,'compound_features':compounds,'relations':relations,
            'base_names':BASE_NAMES,'compound_names':COMPOUND_NAMES,'threshold':threshold,
            'confidence_calibrated':False,'compound_grouping_trained':instances,
            'measurement_policy':'Measure original observed edges; compounds reference retained base instances',
            'unselected_edge_fraction':float(np.mean(primary.max(1)<threshold))}
    return result,dict(primary=primary,semantic=semantic,compound=compound,defect=defect,boundary=boundary,classes=classes)

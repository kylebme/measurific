"""Small shared encoder, primitive segmentation, secondary compound classification.

Compound segmentation sees learned primitive probabilities and contour context.
Queries associate repeated spans; closed slot rings need no fixed query budget.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import time
import numpy as np
import torch
from torch.nn import functional as F
from scipy.optimize import linear_sum_assignment
from inspection_shapes.primitive_labels import LABEL_VERSION, BASE_NAMES, COMPOUND_NAMES
from .model import ContourTransformer, ModelConfig
from .data import load_cached, augment
from .train import load_model, model_device


def query_loss(out, target):
    logits=out['query_class']; masks=out['query_masks']; truth=target['instance_masks']
    classes=target['instance_classes'].long(); weights=target['weights']/target['weights'].sum()
    labels=torch.zeros(len(logits),dtype=torch.long,device=logits.device)
    if len(classes)>len(logits):raise ValueError('Repeat query capacity exceeded')
    if not len(classes):return F.cross_entropy(logits,labels)
    with torch.no_grad():
        prob=masks.sigmoid(); inter=(prob*weights)@truth.T
        den=(prob*weights).sum(1)[:,None]+(truth*weights).sum(1)[None]
        cost=-logits.softmax(-1)[:,classes]+2*(1-(2*inter+1e-6)/(den+1e-6))
        ri,ci=linear_sum_assignment(cost.float().cpu().numpy())
    labels[ri]=classes[ci]
    ce=F.cross_entropy(logits,labels,weight=logits.new_tensor([.15,1,1,1,1]))
    selected=masks[ri]; actual=truth[ci]; prob=selected.sigmoid()
    bce=(F.binary_cross_entropy_with_logits(selected,actual,reduction='none')*weights).sum(-1).mean()
    dice=(1-(2*(prob*actual*weights).sum(-1)+1e-6)/((prob+actual).mul(weights).sum(-1)+1e-6)).mean()
    return ce+bce+2*dice


def losses(out,t,base_weights,compound_weights,query_weight=1.):
    w=t['weights']/t['weights'].sum()
    base=-(t['primary']*F.log_softmax(out['primary'],-1)*base_weights).sum(-1).mul(w).sum()
    sem=F.binary_cross_entropy_with_logits(out['semantic'],t['semantic'],reduction='none').mean(-1).mul(w).sum()
    boundary=F.binary_cross_entropy_with_logits(out['boundary'],t['boundary'],reduction='none',
                                               pos_weight=w.new_tensor(8)).mul(w).sum()
    compound=-(t['compound']*F.log_softmax(out['compound'],-1)*compound_weights).sum(-1).mul(w).sum()
    defect=-(t['defect']*F.log_softmax(out['defect'],-1)*w.new_tensor([.2,2,2])).sum(-1).mul(w).sum()
    query=query_loss(out,t)
    return base+.25*sem+.6*boundary+compound+.15*defect+query_weight*query


def metrics(conf,names,skip_zero=True):
    tp=np.diag(conf);support=conf.sum(1);pred=conf.sum(0)
    f1=2*tp/np.maximum(support+pred,1e-12)
    present=support>0
    if skip_zero:present[0]=False
    return {'macro_f1':float(f1[present].mean()) if present.any() else 0.,
            'accuracy':float(tp.sum()/max(conf.sum(),1e-12)),
            'classes':{name:{'f1':float(f1[i]),'precision':float(tp[i]/max(pred[i],1e-12)),
                             'recall':float(tp[i]/max(support[i],1e-12)),
                             'support_length':float(support[i])} for i,name in enumerate(names)},
            'confusion':conf.tolist()}


@torch.no_grad()
def evaluate(model,entries,cache,device):
    model.eval();base=np.zeros((5,5));compound=np.zeros((5,5));boundary=np.zeros(4)
    query_counts=np.zeros(3);families={}
    for e in entries:
        a=load_cached(Path(cache)/e['file'])
        out=model(torch.as_tensor(a['x'],device=device),a['offsets'],instances=True)
        w=a['weights']
        for key,conf in [('primary',base),('compound',compound)]:
            p=out[key].argmax(-1).cpu().numpy();t=a[key].argmax(-1)
            c=np.bincount(5*t+p,weights=w,minlength=25).reshape(5,5);conf+=c
            if key=='primary':families.setdefault(e['family'],np.zeros((5,5)));families[e['family']]+=c
        p=out['boundary'].sigmoid().cpu().numpy()>.5;t=a['boundary']>.75
        for lo,hi in zip(a['offsets'][:-1],a['offsets'][1:]):
            pp,tt=p[lo:hi],t[lo:hi]
            pd=pp|np.roll(pp,1)|np.roll(pp,-1);td=tt|np.roll(tt,1)|np.roll(tt,-1)
            boundary+=[(pp&td).sum(),pp.sum(),(tt&pd).sum(),tt.sum()]
        cls=out['query_class'].argmax(-1).cpu().numpy();keep=cls>=2
        masks=out['query_masks'].sigmoid().cpu().numpy()[keep]>.5
        actual=a['instance_masks']>.5
        matched=0
        if len(masks) and len(actual):
            inter=(masks*w)@actual.T
            union=(masks*w).sum(1)[:,None]+(actual*w).sum(1)[None]-inter
            iou=inter/np.maximum(union,1e-8)
            iou*=cls[keep,None]==a['instance_classes'][None]
            ri,ci=linear_sum_assignment(-iou);matched=int((iou[ri,ci]>=.5).sum())
        query_counts += [matched,len(masks),len(actual)]
    precision=query_counts[0]/max(query_counts[1],1);recall=query_counts[0]/max(query_counts[2],1)
    result={'samples':len(entries),'base':metrics(base,BASE_NAMES),
            'compound':metrics(compound,COMPOUND_NAMES),
            'repeat_instances':{'precision_iou50':float(precision),'recall_iou50':float(recall),
                                'f1_iou50':float(2*precision*recall/max(precision+recall,1e-12)),
                                'counts':query_counts.tolist()},
            'boundary':{'precision':float(boundary[0]/max(boundary[1],1)),
                        'recall':float(boundary[2]/max(boundary[3],1))},
            'by_family':{f:metrics(c,BASE_NAMES)['macro_f1'] for f,c in families.items()}}
    result['selection_score']=.7*result['base']['macro_f1']+.2*result['compound']['macro_f1']+.1*result['repeat_instances']['f1_iou50']
    return result


def train(cache,output,steps=12000,seed=42,width=64,backbone='transformer',lr=3e-4,
          eval_every=1000,val_limit=200,device='cuda',init=None,query_weight=.5):
    cache=Path(cache);output=Path(output);output.mkdir(parents=True,exist_ok=True)
    if (output/'config.json').exists():raise ValueError('Use a new experiment directory')
    torch.set_num_threads(2);torch.manual_seed(seed);rng=np.random.default_rng(seed);dev=model_device(device)
    config=json.loads((cache/'config.json').read_text())
    if config['label_version']!=LABEL_VERSION:raise ValueError('Wrong label schema')
    index=json.loads((cache/'index.json').read_text())
    training=[e for e in index if e['split']=='train'];validation=[e for e in index if e['split']=='val']
    # Stable shuffle spreads validation coverage over families and complexities.
    np.random.default_rng(100).shuffle(validation)
    if val_limit:validation=validation[:val_limit]
    model=ContourTransformer(ModelConfig(width=width,global_width=width*2,queries=32,
        adaptive_sampling=True,topology_instances=False,query_scope='compounds',
        sampling_version=config['sampling'],label_schema=LABEL_VERSION,backbone=backbone)).to(dev)
    if init:
        old=torch.load(init,map_location='cpu',weights_only=True)
        state=model.state_dict()
        for k,v in old['model'].items():
            if k in state and state[k].shape==v.shape:state[k]=v
        model.load_state_dict(state)
    optimizer=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=.01)
    scaler=torch.amp.GradScaler('cuda',enabled=dev.type=='cuda')
    hist=np.zeros(5);chist=np.zeros(5);total=0
    for e in training[:500]:
        a=load_cached(cache/e['file']);hist+=(a['primary']*a['weights'][:,None]).sum(0)
        chist+=(a['compound']*a['weights'][:,None]).sum(0);total+=a['weights'].sum()
    bw=torch.tensor(np.clip(np.sqrt(total/np.maximum(hist,1)),1,8),device=dev,dtype=torch.float32)
    cw=torch.tensor(np.clip(np.sqrt(total/np.maximum(chist,1)),1,8),device=dev,dtype=torch.float32)
    fingerprint=hashlib.sha256((cache/'config.json').read_bytes()+(cache/'index.json').read_bytes()).hexdigest()
    settings=dict(cache=str(cache.resolve()),steps=steps,seed=seed,width=width,backbone=backbone,lr=lr,
                  query_weight=query_weight,init=str(init) if init else None,sampling=config['sampling'],
                  tokens=None,validation_ids=[e['id'] for e in validation],train_samples=len(training),
                  label_version=LABEL_VERSION,selection_policy='70% base macro F1 + 20% compound macro F1 + 10% repeat instance F1')
    (output/'config.json').write_text(json.dumps(settings,indent=2))
    print(f'Training {sum(p.numel() for p in model.parameters()):,} parameters; {len(training)} train, {len(validation)} val',flush=True)
    best=-1;start=time.monotonic();loss_sum=0
    for step in range(1,steps+1):
        model.train();a=load_cached(cache/training[int(rng.integers(len(training)))]['file'])
        # Augmentation must apply the identical permutation to compound targets.
        joined=np.concatenate([a['semantic'],a['compound']],axis=1);a['semantic']=joined
        a=augment(a,rng,relative_noise=True)
        a['compound']=a['semantic'][:,4:];a['semantic']=a['semantic'][:,:4]
        t={k:torch.as_tensor(v,device=dev) for k,v in a.items() if k not in ('x','offsets')}
        multiplier=min(1,step/max(1,steps*.03))*(.15+.85*(1+math.cos(math.pi*step/steps))/2)
        for g in optimizer.param_groups:g['lr']=lr*multiplier
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=dev.type,dtype=torch.float16,enabled=dev.type=='cuda'):
            out=model(torch.as_tensor(a['x'],device=dev),a['offsets'],instances=True)
            loss=losses(out,t,bw,cw,query_weight)
        if not torch.isfinite(loss):raise FloatingPointError(f'Nonfinite loss at step {step}')
        scaler.scale(loss).backward();scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.);scaler.step(optimizer);scaler.update()
        loss_sum+=float(loss.detach())
        if step%100==0:print(f'step {step}/{steps}, elapsed {time.monotonic()-start:.0f}s',flush=True)
        if step%eval_every==0 or step==steps:
            report=evaluate(model,validation,cache,dev)
            report.update(step=step,loss=loss_sum/min(step,eval_every),elapsed_seconds=time.monotonic()-start,
                          peak_cuda_mb=torch.cuda.max_memory_allocated()/1e6 if dev.type=='cuda' else 0)
            with (output/'history.jsonl').open('a') as f:f.write(json.dumps(report)+'\n')
            print(json.dumps({k:report[k] for k in ('step','loss','selection_score','elapsed_seconds')}),flush=True)
            checkpoint=dict(model=model.state_dict(),model_config=model.metadata(),step=step,label_version=LABEL_VERSION,
                            instances_trained=True,settings=settings,data_fingerprint=fingerprint,report=report,
                            optimizer=optimizer.state_dict(),scaler=scaler.state_dict(),
                            numpy_rng_state=json.dumps(rng.bit_generator.state),torch_rng_state=torch.get_rng_state())
            torch.save(checkpoint,output/'last.pt')
            if report['selection_score']>best:
                best=report['selection_score'];torch.save(checkpoint,output/'best.pt')
                (output/'best-report.json').write_text(json.dumps(report,indent=2))
            loss_sum=0
    return output/'best.pt'


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('cache');p.add_argument('output')
    p.add_argument('--steps',type=int,default=12000);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--width',type=int,default=64);p.add_argument('--backbone',choices=['transformer','conv'],default='transformer')
    p.add_argument('--lr',type=float,default=3e-4);p.add_argument('--eval-every',type=int,default=1000)
    p.add_argument('--val-limit',type=int,default=200);p.add_argument('--device',default='cuda')
    p.add_argument('--init');p.add_argument('--query-weight',type=float,default=.5)
    train(**vars(p.parse_args()))
